# Revision record and research handoff

## Persistent task context

The user requested a complete academic and visual redesign of EchoTrace, not grammar editing.
The sole author must be **Ayush Dev**. Do not invent affiliations, co-authors, supervisors,
reviewers, completed experiments, or results. The user confirmed `paper/main.pdf` as the target.

## Delivered revision

- Reframed the paper as a source-dependence framework with exploratory component evidence.
- Replaced the plain article/ACL fallback with IEEEtran conference typography and numbered citations.
- Added explicit family semantics, a conditional-dependence odds example, loss function,
  metric denominators, complexity analysis, and a documented selection algorithm.
- Added vector concept/pipeline diagrams and generated validation plots and tables.
- Added foundational source-dependence and MMR references; verified existing records against
  ACL Anthology, arXiv author metadata, BMJ, and the author's source-dependence paper.
- Reported actual validation measurements, with per-case evidence and source hashes.
- Preserved the original manuscript and PDF in `archive/`.

## Numerical evidence

Run `scripts/paper_validation.py` from the repository root. It trains on 240 cases, supplies gold
supporters, and evaluates 60 validation cases (12 worlds). It does not run held-out model tests.
EchoGraph default threshold 0.60: MAE 0.766667, conditional FCR 0.333333, pair F1 0.709524.
The paired world bootstrap interval is descriptive of the generated validation set, not a claim
of generalization or confirmatory significance. The threshold had already been examined by the
legacy diagnostic; the new analysis is explicitly exploratory.

## Research issues requiring resolution before model claims

1. IDs and URLs encode condition and role; the validator misses coded leakage. Randomize opaque IDs.
2. All 400 gold verdicts are supported. Distinguish reporting accuracy from factual truth, balance
   outcome classes, and make conflict adjudication meaningful before using verdict utility.
3. All documents have distinct domains. Domain grouping equals URL counting by construction.
4. Root independence is stipulated; short texts may not identify separate acquisition processes.
   Improve visible provenance or allow ambiguous cases and abstention.
5. Dates, wording, and domains change with condition. Control or independently randomize nuisance cues.
6. The classifier learns same-family affinity, not parent-child copying. Use matched pair labels;
   do not score affinity edges as direct-lineage reconstruction without redefining the target.
7. Legacy graph evaluation counts all-document components against supporter-only roots.
   The new paper script avoids this mismatch; the legacy runner remains unchanged.
8. Legacy agent FCR averages over all cases; the paper conditions on one-root cases. Harmonize
   denominators before new model runs and include missingness in reporting.
9. The nominally naturalistic prompt already instructs independence reasoning. Separate a genuinely
   unprimed track from diagnostic elicitation and freeze prompts before experiments.
10. `embedding_dedup` uses lexical bag-of-words metadata with no embedding model or actual filtering.
    Rename it in a future runner revision; the paper describes its real behavior.
11. Support-only training differs from mixed-corpus inference. Add relevant negative pairs or an
    explicit support-identification stage; evaluate both component and end-to-end behavior.
12. The adapter recomputes groups on selected context, potentially removing graph bridges. Evaluate
    projected selection-time groups and isolate selection from metadata effects.
13. Legacy coverage uses recorded attempts, not all scheduled cases; count unattempted cases and
    reconcile failed/retried calls with actual billing before cost or coverage claims.
14. Human review and the 30-cluster live audit are pending. Proposed reviewer roles do not imply
    recruited people or additional manuscript authors.
15. `PROTOCOL.md` is an uncompleted checklist. Archive a revised protocol with fixed endpoint,
    model comparisons, corrected metrics, coverage definition, and utility noninferiority rule
    before describing an evaluation as preregistered.

These issues are disclosed in the paper. The dataset and legacy model runner were not silently
rewritten, and the manuscript does not suggest they have been repaired.

## Reference verification

Verified during this revision on 2026-09-11 using primary sources:

- ALCE: https://aclanthology.org/2023.emnlp-main.398/
- Citation-network analysis: https://www.bmj.com/content/339/bmj.b2680
- Source dependence: https://lunadong.com/publication/dependence_vldb.pdf
- MMR: https://aclanthology.org/X98-1025/
- DeepResearch Bench: https://arxiv.org/abs/2506.11763
- Cited but Not Verified: https://arxiv.org/abs/2605.06635
- DeepWeb-Bench: https://arxiv.org/abs/2605.21482
- ForceBench: https://arxiv.org/abs/2605.28044
- LineageRAG: https://arxiv.org/abs/2608.16004

arXiv entries remain identified as preprints; they are not represented as peer-reviewed publications.

## Final verification

The final seven-page PDF compiled with embedded fonts and no overfull boxes or unresolved
citations/references. All seven pages were visually inspected (the revised last page was
inspected again). The existing 18 unit tests pass. Artifact hashes, validation case/world
counts, conditional FCR denominators, and the analytical URL-count baseline were verified.
