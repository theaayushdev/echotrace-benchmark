# EchoTrace manuscript

Author: **Ayush Dev** (sole author). Affiliation is intentionally a placeholder.

`main.pdf` is the redesigned IEEE-style manuscript. `main.tex`, `references.bib`,
`figures/validation.pdf`, and `generated/validation-rows.tex` are the editable source assets.
The conceptual diagrams and algorithm are native LaTeX/TikZ. Plot data and case-level results
are in `../artifacts/paper-validation.json`. Originals are preserved in `archive/`.

## Build

From the repository root, using the existing local Tectonic installation:

```bash
OPENBLAS_NUM_THREADS=1 python3 scripts/paper_validation.py
.tools/tectonic/tectonic --keep-logs paper/main.tex
```

Analysis dependencies: Python 3.10+, NumPy, Matplotlib. The reported environment used
NumPy 1.26.4 and Matplotlib 3.6.3. No API key, provider call, or paid model is needed.
Tectonic downloads missing TeX packages on its first build.

Alternatively, upload the manuscript source ZIP to Overleaf, select `main.tex`, and compile;
or run `latexmk -pdf main.tex` inside this directory with an IEEEtran-enabled TeX distribution.
Existing generated assets allow compiling without rerunning Python.

## Evidence status

This is a complete rewrite and a compiled research manuscript, not a completed confirmatory
research study. The numerical table is a measured, exploratory **validation component analysis
with oracle supporting-document membership**. The test split is not evaluated by the new script.
No language-model performance, human verification, or completed live-web audit is claimed.
The document explains these limits in the abstract, results, and conclusion.

The legacy `generated/results.tex` is retained for compatibility with the old agent exporter,
but is not included by this manuscript. Do not replace the validation table with mock-agent data.
See `EDITORIAL_NOTES.md` for the scientific issues and remaining research work.

IEEEtran provides the requested conference appearance. A specific venue has not been selected;
page limits, anonymous-review requirements, and final submission formatting remain venue-specific.
